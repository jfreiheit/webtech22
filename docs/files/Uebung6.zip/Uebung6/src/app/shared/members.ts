export interface Members {
    forename: string;
    surname: string;
    email: string;
}
