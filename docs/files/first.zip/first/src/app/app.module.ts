import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EinsComponent } from './eins/eins.component';
import { ZweiComponent } from './zwei/zwei.component';

@NgModule({
  declarations: [
    AppComponent,
    EinsComponent,
    ZweiComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
