import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZweiComponent } from './zwei.component';

describe('ZweiComponent', () => {
  let component: ZweiComponent;
  let fixture: ComponentFixture<ZweiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZweiComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ZweiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
