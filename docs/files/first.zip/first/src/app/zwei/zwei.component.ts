import { Component } from '@angular/core';

@Component({
  selector: 'app-zwei',
  templateUrl: './zwei.component.html',
  styleUrls: ['./zwei.component.css']
})
export class ZweiComponent {

}
