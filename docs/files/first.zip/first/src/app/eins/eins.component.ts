import { Component } from '@angular/core';

@Component({
  selector: 'app-eins',
  templateUrl: './eins.component.html',
  styleUrls: ['./eins.component.css']
})
export class EinsComponent {

}
