import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EinsComponent } from './eins.component';

describe('EinsComponent', () => {
  let component: EinsComponent;
  let fixture: ComponentFixture<EinsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EinsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EinsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
