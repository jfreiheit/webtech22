import { ListeComponent } from './liste/liste.component';
import { TableComponent } from './table/table.component';
import { StartComponent } from './start/start.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path: 'start', title: 'Start', component: StartComponent},
  {path: 'table', title: 'Table', component: TableComponent},
  {path: 'list', title: 'Liste', component: ListeComponent},
  {path: '', component: StartComponent},
  {path: '**', component: StartComponent, redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
