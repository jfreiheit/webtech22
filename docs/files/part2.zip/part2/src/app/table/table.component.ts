import { Component, OnInit } from '@angular/core';
import { Stadt } from '../shared/stadt';
import { StaedteService } from '../shared/staedte.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit{
  title: string = "Alle Städte";
  staedte: Stadt[] = [];
  btn_text = "Verstecke Tabelle"
  show = true;

  constructor(private staedteService: StaedteService) {}

  ngOnInit() {
    this.staedteService.getStaedte()
    .then( resp => {
      this.staedte = resp;
      console.log(this.staedte)
    })
  }

  showTable() {
    if(this.btn_text == "Verstecke Tabelle")
    {
      this.btn_text = "Zeige Tabelle";
      this.show = false;
    }
    else
    {
      this.btn_text = "Verstecke Tabelle";
      this.show = true;
    }
  }

}
