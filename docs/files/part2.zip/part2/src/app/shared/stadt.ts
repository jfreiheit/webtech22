export interface Stadt {
  id: number;
  jahr: number;
  stadt: string;
  link: string;
  bild: string;
}
