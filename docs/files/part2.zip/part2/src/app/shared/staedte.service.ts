import { Injectable } from '@angular/core';
import { Stadt } from './stadt';

@Injectable({
  providedIn: 'root'
})
export class StaedteService {

  constructor() { }

  async getStaedte(): Promise<Stadt[]> {
    let response = await fetch('./assets/staedte.json');
    let staedteObj = await response.json();

    return staedteObj.staedte;
  }
}
