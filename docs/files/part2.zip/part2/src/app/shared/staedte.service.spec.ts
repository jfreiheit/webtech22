import { TestBed } from '@angular/core/testing';

import { StaedteService } from './staedte.service';

describe('StaedteService', () => {
  let service: StaedteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StaedteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
